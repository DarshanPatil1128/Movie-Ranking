﻿using Microsoft.EntityFrameworkCore;

namespace MovieRankApi.Model
{
    public class MovieRating
    {
        public int Id { get; set; }
        public string MovieTitle { get; set; }
        public int Ranking { get; set; }
    }

    public class MovieRatingContext : DbContext
    {
        public MovieRatingContext(DbContextOptions<MovieRatingContext> options) : base(options)
        {
        }

        public DbSet<MovieRating> MovieRatings { get; set; }
    }
}
