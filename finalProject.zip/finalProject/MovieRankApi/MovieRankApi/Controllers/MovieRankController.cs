﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.SignalR;
using Microsoft.EntityFrameworkCore;
using MovieRankApi.Model;

namespace MovieRankApi.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class MovieRatingController : ControllerBase
    {
        private readonly MovieRatingContext _context;
        private readonly IHubContext<MovieRatingHub> _hubContext;

        public MovieRatingController(MovieRatingContext context, IHubContext<MovieRatingHub> hubContext)
        {
            _context = context;
            _hubContext = hubContext;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<MovieRating>>> GetMovieRatings()
        {
            try
            {
                return await _context.MovieRatings.ToListAsync();
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<MovieRating>> GetMovieRating(int id)
        {
            var movieRating = await _context.MovieRatings.FindAsync(id);

            if (movieRating == null)
            {
                return NotFound();
            }

            return movieRating;
        }

        [HttpPost]
        public async Task<ActionResult<MovieRating>> PostMovieRating(MovieRating movieRating)
        {
            _context.MovieRatings.Add(movieRating);
            await _context.SaveChangesAsync();

            await _hubContext.Clients.All.SendAsync("MovieRatingAdded", movieRating);

            return CreatedAtAction("GetMovieRating", new { id = movieRating.Id }, movieRating);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> PutMovieRating(int id, MovieRating movieRating)
        {
            if (id != movieRating.Id)
            {
                return BadRequest();
            }

            _context.Entry(movieRating).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!MovieRatingExists(id))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            await _hubContext.Clients.All.SendAsync("MovieRatingUpdated", movieRating);

            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteMovieRating(int id)
        {
            var movieRating = await _context.MovieRatings.FindAsync(id);
            if (movieRating == null)
            {
                return NotFound();
            }

            _context.MovieRatings.Remove(movieRating);
            await _context.SaveChangesAsync();

            await _hubContext.Clients.All.SendAsync("MovieRatingDeleted", id);

            return NoContent();
        }

        private bool MovieRatingExists(int id)
        {
            return _context.MovieRatings.Any(e => e.Id == id);
        }
    }
}
