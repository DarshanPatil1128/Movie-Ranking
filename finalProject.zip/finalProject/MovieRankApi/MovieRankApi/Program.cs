using Microsoft.AspNetCore.SignalR;
using Microsoft.EntityFrameworkCore;
using MovieRankApi.Model;
using System;
using System.Globalization;

var builder = WebApplication.CreateBuilder(args);
var culture = CultureInfo.InvariantCulture;
CultureInfo.DefaultThreadCurrentCulture = culture;
CultureInfo.DefaultThreadCurrentUICulture = culture;



// Add services to the container.
builder.Services.AddDbContext<MovieRatingContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("MovieRatingContext")));

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddSignalR();
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowLocalhost", builder =>
        builder.WithOrigins("https://localhost:44306") // Blazor frontend URL
               .AllowAnyHeader()
               .AllowAnyMethod());
});

var app = builder.Build();
//app.MapHub<MovieRatingHub>("/ratingHub");

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

// Add these lines to fix the routing issue:
app.UseRouting();

app.UseAuthorization();

// Configure endpoints:
app.UseEndpoints(endpoints =>
{
    endpoints.MapControllers();
    endpoints.MapHub<MovieRatingHub>("/ratingHub");
});

app.Run();
